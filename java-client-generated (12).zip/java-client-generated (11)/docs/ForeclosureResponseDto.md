# ForeclosureResponseDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**walletValue** | **Double** |  |  [optional]
**foreclosureResponseCode** | [**ForeclosureResponseCodeEnum**](#ForeclosureResponseCodeEnum) |  |  [optional]

<a name="ForeclosureResponseCodeEnum"></a>
## Enum: ForeclosureResponseCodeEnum
Name | Value
---- | -----
USER_NOT_FOUND | &quot;USER_NOT_FOUND&quot;
SUCCESSFUL_LOCKED | &quot;SUCCESSFUL_LOCKED&quot;
SUCCESSFUL_UNLOCKED | &quot;SUCCESSFUL_UNLOCKED&quot;
ALREADY_DEREGISTERED | &quot;ALREADY_DEREGISTERED&quot;
NOTHING_DONE | &quot;NOTHING_DONE&quot;
INTERNAL_ERROR | &quot;INTERNAL_ERROR&quot;
