# BankdataApiApi

All URIs are relative to *https://lfapi-test.pais.corp*

Method | HTTP request | Description
------------- | ------------- | -------------
[**handleBankdataValidationResults**](BankdataApiApi.md#handleBankdataValidationResults) | **POST** /api/customer/bankdata/validationresults | Endpoint to handle bankdata validation results (ADIV). Matches BPM818

<a name="handleBankdataValidationResults"></a>
# **handleBankdataValidationResults**
> List&lt;BankdataValidationRequestResponse&gt; handleBankdataValidationResults(body, uuid)

Endpoint to handle bankdata validation results (ADIV). Matches BPM818

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BankdataApiApi;


BankdataApiApi apiInstance = new BankdataApiApi();
List<AdivValidationResponse> body = Arrays.asList(new AdivValidationResponse()); // List<AdivValidationResponse> | 
String uuid = "uuid_example"; // String | 
try {
    List<BankdataValidationRequestResponse> result = apiInstance.handleBankdataValidationResults(body, uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BankdataApiApi#handleBankdataValidationResults");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**List&lt;AdivValidationResponse&gt;**](AdivValidationResponse.md)|  |
 **uuid** | **String**|  |

### Return type

[**List&lt;BankdataValidationRequestResponse&gt;**](BankdataValidationRequestResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

