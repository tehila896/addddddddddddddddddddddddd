# ChargebackApiApi

All URIs are relative to *https://lfapi-test.pais.corp*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateChargebacks**](ChargebackApiApi.md#updateChargebacks) | **POST** /api/customer/chargeback | Update chargebacks. Matches BPM304

<a name="updateChargebacks"></a>
# **updateChargebacks**
> List&lt;UpdateChargebackDataResponse&gt; updateChargebacks(body, uuid)

Update chargebacks. Matches BPM304

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ChargebackApiApi;


ChargebackApiApi apiInstance = new ChargebackApiApi();
UpdateChargebackDataRequest body = new UpdateChargebackDataRequest(); // UpdateChargebackDataRequest | 
String uuid = "uuid_example"; // String | 
try {
    List<UpdateChargebackDataResponse> result = apiInstance.updateChargebacks(body, uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ChargebackApiApi#updateChargebacks");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdateChargebackDataRequest**](UpdateChargebackDataRequest.md)|  |
 **uuid** | **String**|  |

### Return type

[**List&lt;UpdateChargebackDataResponse&gt;**](UpdateChargebackDataResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

