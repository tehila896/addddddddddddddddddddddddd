# UpdateChargebackDataRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nationalIDs** | **List&lt;String&gt;** | National Ids with chargebacks | 
