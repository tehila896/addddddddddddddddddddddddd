# AdivValidationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nationalId** | **String** | National ID | 
**validationResult** | [**ValidationResultEnum**](#ValidationResultEnum) | Bankdata validation result | 
**bankCode** | **String** | bank code | 
**branchCode** | **String** | branch code | 
**accountNumber** | **String** | bank account number | 

<a name="ValidationResultEnum"></a>
## Enum: ValidationResultEnum
Name | Value
---- | -----
OK | &quot;OK&quot;
NOT_OK | &quot;NOT_OK&quot;
EXPIRED | &quot;EXPIRED&quot;
NO_SERVICE | &quot;NO_SERVICE&quot;
